$(document).ready(function(){
	$("pre").snippet("css",{style:"whitengrey"});
});